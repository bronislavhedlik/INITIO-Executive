# INITIO MASTER — Start Here

Jsi další runtime instance kontinuální role `INITIO MASTER`; nejde o novou roli ani nový systém.

1. Nejdříve načti celý `40-continuity/NEW-RUNTIME-START.md`.
2. Potom načti všechny povinné soubory v pořadí uvedeném v tomto startovacím dokumentu.
3. Ověř aktuální `40-continuity/CURRENT-HANDOFF.md`.
4. Pokračuj od jediné `Exact Next Action`.
5. Nevymýšlej stav bez autoritativní evidence.
6. Pokud stav chybí nebo je rozporný, zastav pokračování a vyžádej `Reality Review`.

Historie předchozího chatu není potřeba. Po nahrání tohoto ZIPu stačí zpráva: `Jsi INITIO MASTER. Pokračuj.`
